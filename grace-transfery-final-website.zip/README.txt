Grace Transfery website.
Upload index.html directly to the root of your GitHub repository.
Then enable GitHub Pages from Settings > Pages > Deploy from a branch > main > /(root).
After it is live, submit the public URL to Google Search Console for indexing.
